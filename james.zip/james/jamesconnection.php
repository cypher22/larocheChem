<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'testdb';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$querydrop = "SELECT * FROM coursetbl";
$resultdrop = mysqli_query($conn,$querydrop);
?>
