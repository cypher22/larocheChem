<!DOCTYPE html>
<link rel="stylesheet" href="style.css" />
<html>
<title>CodeForm1</title>
<head>
<form  method="post" action="code.php">
<input type="hidden" name="submitted" value="true"/>
<h3>La Roche College
<br> Department of Chemistry
    <br> Course Assessment Form</h3>
</head>
<body>
<label>
<img src="icon.jpg" alt="Icon" style="width:304px;height:228px; float: right">
<font color="red">Course Sec:</font>
    <select name= "coursecode">
    <option value="Select a Course">Select a Course</option> 
    <option value="MATH0010-01">MATH0010-01</option>//Basic Mathematics
    <option value="CSCI3040-0A">CSCI3040-0A</option>//Operating Systems
    <option value="CHEM2015-01">CHEM2015-01</option>//Chemistry 
    <option value="CHEM2015L-01">CHEM2015L-01</option>//Chemistry  Lab  
      
    </select>
    </label>
<input type = "submit" />
</form>
    
</html>

<?php
  
if(isset($_POST["submitted"])){
    
include('jamesconnection.php');
$coursecode = $_POST["coursecode"];
$Course = 'Course';
$query = "SELECT * FROM coursestbl WHERE '$coursecode' = $Course";    
$result = mysqli_query($conn, $query) or die("error: $query");

while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
   echo"<br>Course: ";
    echo"<br><input id='s' type='text'  name='Course' value={$row['Course']} size='20' />";
    
   echo"<br>CourseTitle: ";
    echo"<br><input type='text'  name='CourseTitle' value={$row['Course Title']} size='20' />";
    
    echo"<br>Semester: ";
    echo"<br><input id='s' type='text'  name='semester' value={$row['Semester']} size='20' />";
    
    echo"Instructor: ";
      echo "<br><input type='text' id='' name='Instructor' value={$row['Instructor']} size='20' />";
}
}

?>
</body>

